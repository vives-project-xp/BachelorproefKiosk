console.log("Loaded");

const backendAddr = "10.10.18.5:3000"